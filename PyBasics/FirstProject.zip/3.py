
z = "my name is don"
s = ["hello", "cool"]
p = ("hello", "baby")
c = "hello","hello"
print(type(z.endswith("don")))

