# 1 2 3
# 2 3 4
# 3 4 5
# 4 5 6

x = 1
y = 4

# while y > 0:
for i in range(4):
    for j in range(4-1):
     print(j+i+1, end=' ')
    # y = y - 1
    print("")
