var1 = "hello"
var2 = 64
var3 = 4.2
var4 = 'hello'
var6 = str(type(var4))
var5 = var6 + " right"
print(var1[1])
