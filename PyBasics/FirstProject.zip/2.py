
z = "my name is don"
print(z.endswith("don"))
print(z.count("o"))
print(z.capitalize())
print(z.find("is"))
print(z.upper())
z.upper()
