
for i in range(500):
  c = i ** (1.0 / 3.0)
  if c%1==0:
    print(i, " is perfect cube root.")


# for i in range(10,0,-1):
#     print(i)
