

x = 1
y = 4

while x <= 100:
   if x%5!=0 and x%3!=0:
          print(x , end=" ")
          if x % 7 == 0:
             print()
   x = x + 1
